<?php
/**
 * Created by PhpStorm.
 * User: Thilina
 * Date: 2019-02-03
 * Time: 01.25
 */

class FlowerStore extends Page{



}
